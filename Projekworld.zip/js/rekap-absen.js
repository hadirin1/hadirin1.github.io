window.onload = loadRekap;

function loadRekap(){
  let table = document.getElementById("rekapAbsen");
  let data = JSON.parse(localStorage.getItem("absenData")) || [];

  table.innerHTML = `
    <tr>
      <th>No</th>
      <th>Username</th>
      <th>Kode ROM</th>
      <th>Status</th>
      <th>Waktu</th>
    </tr>
  `;

  if(data.length === 0){
    table.innerHTML += `
      <tr>
        <td colspan="5">Belum ada data</td>
      </tr>
    `;
    return;
  }

  data.forEach((item, i)=>{
    table.innerHTML += `
      <tr>
        <td>${i+1}</td>
        <td>${item.username}</td>
        <td>${item.rom}</td>
        <td>${item.status || "-"}</td>
        <td>${item.waktu}</td>
      </tr>
    `;
  });
}
function hapusRekapAbsen(){
  let user = JSON.parse(localStorage.getItem("loginUser"));

  if(!user || user.role !== "admin"){
    alert("Hanya admin yang bisa menghapus!");
    return;
  }

  let yakin = confirm("Yakin mau hapus semua rekap absen?");
  if(!yakin) return;

  localStorage.removeItem("absenData");
  alert("Rekap absen berhasil dihapus ✅");

  loadRekap();
}